AI Attendance Flutter App (Auto-generated)
