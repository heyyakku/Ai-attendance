import 'package:http/http.dart' as http;

class ApiService {
  final String baseUrl;
  ApiService({required this.baseUrl});

  Future<Map<String, dynamic>> login(String user, String pass) async {
    final res = await http.post(
      Uri.parse('$baseUrl/login'),
      body: {'username': user, 'password': pass},
    );
    return {'statusCode': res.statusCode, 'body': res.body};
  }
}
