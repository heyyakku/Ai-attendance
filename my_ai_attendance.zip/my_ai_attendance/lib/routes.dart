import 'package:flutter/material.dart';
import 'pages/login_page.dart';
import 'pages/dashboard_page.dart';
import 'pages/camera_page.dart';

final Map<String, WidgetBuilder> appRoutes = {
  '/': (ctx) => LoginPage(),
  '/dashboard': (ctx) => DashboardPage(),
  '/camera': (ctx) => CameraPage(),
};
