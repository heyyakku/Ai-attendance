import 'package:flutter/material.dart';
import '../widgets/neon_card.dart';

class DashboardPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Admin Dashboard")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: NeonCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Today: ${DateTime.now().toString().split(' ')[0]}"),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () => Navigator.pushNamed(context, '/camera'),
                child: Text("Mark Attendance (Camera)"),
              )
            ],
          ),
        ),
      ),
    );
  }
}
