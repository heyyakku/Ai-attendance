import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/api_service.dart';
import '../widgets/neon_card.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final userCtrl = TextEditingController();
  final passCtrl = TextEditingController();

  bool loading = false;

  void doLogin() async {
    final api = Provider.of<ApiService>(context, listen: false);

    setState(() => loading = true);

    final res = await api.login(userCtrl.text.trim(), passCtrl.text.trim());

    setState(() => loading = false);

    if (res['statusCode'] == 200) {
      Navigator.pushReplacementNamed(context, '/dashboard');
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Login Failed")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: NeonCard(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text("Login", style: TextStyle(fontSize: 22)),
              SizedBox(height: 20),
              TextField(controller: userCtrl, decoration: InputDecoration(hintText: "Username")),
              SizedBox(height: 10),
              TextField(controller: passCtrl, decoration: InputDecoration(hintText: "Password"), obscureText: true),
              SizedBox(height: 20),
              loading
                  ? CircularProgressIndicator()
                  : ElevatedButton(onPressed: doLogin, child: Text("Login")),
            ],
          ),
        ),
      ),
    );
  }
}
