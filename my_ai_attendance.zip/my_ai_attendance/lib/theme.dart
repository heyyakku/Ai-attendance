import 'package:flutter/material.dart';

final Color accent = Color(0xFF4C8CFF);
final Color neonBg = Color(0xFF050B1A);

final ThemeData neonTheme = ThemeData.dark().copyWith(
  scaffoldBackgroundColor: neonBg,
  primaryColor: accent,
  colorScheme: ColorScheme.dark(primary: accent, secondary: accent),
);
