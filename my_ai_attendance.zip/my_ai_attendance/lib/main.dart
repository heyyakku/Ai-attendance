import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'routes.dart';
import 'theme.dart';
import 'services/api_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Provider<ApiService>(
      create: (_) => ApiService(baseUrl: 'http://192.168.31.105:5000'), // your Flask base URL
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'AI Attendance',
        theme: neonTheme,
        initialRoute: '/',
        routes: appRoutes,
      ),
    );
  }
}
